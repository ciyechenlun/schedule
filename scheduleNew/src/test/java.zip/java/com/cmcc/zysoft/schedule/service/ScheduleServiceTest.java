package com.cmcc.zysoft.schedule.service;

import static org.junit.Assert.*;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.annotation.Resource;

import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cmcc.zysoft.schedule.model.Schedule;

public class ScheduleServiceTest extends BaseJunitTest{

	@Resource
	private ScheduleService scheduleService;
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
	}

	@Test
	public void testAddConfict() {
		//起始时间到结束时间内存在日程
		SimpleDateFormat df=new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
		try {
			Date start = df.parse("2014-06-11 09:40:20");
			Date end =df.parse("2014-06-11 10:40:20");
			Schedule sc = new Schedule();
			sc.setStartTime(start);
			sc.setEndTime(end);
			int leaderId=1;
			assertEquals("存在冲突", "1", this.scheduleService.add(sc, leaderId));
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}
	@Test
	public void testAddNormal(){
		//正常情况
		SimpleDateFormat df=new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
		try {
			Date start1 = df.parse("2014-06-11 11:40:20");
			Date end1 = df.parse("2014-06-11 14:40:20");
			Schedule sc1 = new Schedule();
			sc1.setStartTime(start1);
			sc1.setEndTime(end1);
			int leaderId1=1;
			
			assertEquals("添加正确", "0", this.scheduleService.add(sc1, leaderId1));
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
